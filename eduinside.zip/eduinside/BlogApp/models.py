from django.db import models
from django.contrib.auth.models import AbstractUser
from .mana_models import userManager
# Create your models here.

class Blog(models.Model):
    post = models.CharField(max_length=50,default='')
    Type = models.CharField(max_length=30,default='')
    content = models.TextField(max_length=1024,default='')
    likes = models.IntegerField(default=0,null=True)
    comments_count = models.IntegerField(default=0,null=True) 

    def __str__(self):
        return self.post

class User(AbstractUser):

    name = models.CharField(max_length=30)
    username = models.CharField(max_length=15,null=False,unique=True)
    email = models.EmailField(max_length=30)
    contact = models.CharField(max_length=10)
    password = models.CharField(max_length=20)
    followers = models.IntegerField(default=0,null=True)
    following = models.IntegerField(default=0,null=True)
    user_follows = models.ManyToManyField('self',related_name='follows',symmetrical=False,blank=True)
    # user_followings = models.ManyToManyField('self',related_name='followings',symmetrical=False,blank=True)
    profile = models.ImageField(default='profile-pic.jpg',upload_to='media')

    objects = userManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = []

    def get_Followers(self):
        return self.user_follows.all()

    def get_Followings(self):
        return User.objects.filter(user_follows=self).all()

    def __str__(self):
        return self.username
    

class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Blog, on_delete=models.CASCADE,related_name='comments')
    body = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now_add=True)
    active = models.BooleanField(default=True)

    def __str__(self): 
        return 'Comment by {} on {}'.format(self.user, self.post)