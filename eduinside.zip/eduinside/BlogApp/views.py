from django.shortcuts import render,HttpResponse,redirect
from django.contrib import messages
from django.contrib.auth.models import User
#  Create your views here.

def home(request):
    return render(request, 'homepage.html')

def initial(request):
    return render(request, 'initial.html')

def blog(request):
    return render(request, 'blog.html')

def login(request):
    return render(request, 'signin.html')

def signup(request):
    if request.method == "POST":
       name = request.POST['name']
       username = request.POST['username']
       email = request.POST['email']
       contact = request.POST['contact']
       password = request.POST['password']
       myuser = User.objects.create_user(name=name,username=username,email=email,contact=contact,password=password)
       myuser.save()
       messages.success(request,"User created!")
       return render('home',{'user':name})
    else:
        return render(request,'register.html')
    

def login(request):
    return render(request, 'signin.html')